package com.msc.dbo;

public class Register
{
	private int strrollno;
	private String strfname;
	private String strlname;
	private String strDOB;
	private String strUname;
	private String strPwd;
	private String strCPwd;
	public int getStrrollno() {
		return strrollno;
	}
	public void setStrrollno(int strrollno) {
		this.strrollno = strrollno;
	}
	public String getStrfname() {
		return strfname;
	}
	public void setStrfname(String strfname) {
		this.strfname = strfname;
	}
	public String getStrlname() {
		return strlname;
	}
	public void setStrlname(String strlname) {
		this.strlname = strlname;
	}
	public String getStrDOB() {
		return strDOB;
	}
	public void setStrDOB(String strDOB) {
		this.strDOB = strDOB;
	}
	public String getStrUname() {
		return strUname;
	}
	public void setStrUname(String strUname) {
		this.strUname = strUname;
	}
	public String getStrPwd() {
		return strPwd;
	}
	public void setStrPwd(String strPwd) {
		this.strPwd = strPwd;
	}
	public String getStrCPwd() {
		return strCPwd;
	}
	public void setStrCPwd(String strCPwd) {
		this.strCPwd = strCPwd;
	}
	
	
	}
