package eclipse;

public class LoginJava {
	private String UserName;
	private String Password;
	
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String uname) {
		this.UserName = uname;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String pwd) {
		this.Password = pwd;
	}
}
