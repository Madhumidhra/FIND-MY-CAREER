package eclipse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LoginServlet() 
    {
    	super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection objConn = null;
		PreparedStatement objStmt = null;
		ResultSet objRs = null;
		String rs = null;
		
		//LoginJava objlogin_java = new LoginJava();
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		//String username = request.getParameter("username");
		//String password  = request.getParameter("password");
		
		try {
			
			Class.forName("org.postgresql.Driver");
			
			objConn= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","postgres");
			
		    String StrQuery = "SELECT rollno, first_name, last_name, dob, uname, pwd, cpwd\r\n"
		    		+ "	FROM \"java project\".register_java where \"uname\" = ? and \"pwd\" = ? ;";
		    
			objStmt = objConn.prepareStatement(StrQuery);
			
			objStmt.setString(1, request.getParameter("uname"));
			objStmt.setString(2, request.getParameter("pwd"));
			
			objRs = objStmt.executeQuery();
			
			
			
			while(objRs.next()) {
				
				 rs = (objRs.getString(5));
				if(!(objRs.getString(6).matches(request.getParameter("pwd")))) {
				RequestDispatcher objdis = request.getRequestDispatcher("Login.jsp");
				objdis.include(request, response);
				out.println("<script type = \"text/javascript\">");
				out.println("alert('INVALID USERNAME OR PASSWORD')"); 
				out.println("</script>");
				}
				else {
					RequestDispatcher objdis = request.getRequestDispatcher("Index.jsp");
					objdis.include(request, response);
					out.println("<script type = \"text/javascript\">");
					out.println("alert('LOGGED IN SUCCESSFULLY')"); 
					out.println("</script>");
				}
			}
			
			if(rs == null) {
				objConn.close();
			    RequestDispatcher objdis = request.getRequestDispatcher("RegisterForm.jsp");
			   objdis.include(request, response);
			   out.println("<script type = \"text/javascript\">");
				out.println("alert('YOUR USERNAME HAS NOT BEEN REGISTERED YET. PLEASE REGISTER')"); 
				out.println("</script>");
			
		}
		}
			
			
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		}
	}
	


