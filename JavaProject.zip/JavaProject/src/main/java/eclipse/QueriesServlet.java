package eclipse;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class QueriesServlet
 */
@WebServlet("/QueriesServlet")
public class QueriesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public QueriesServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection objConn = null;
		PreparedStatement objStmt = null;
		
		try {
			Class.forName("org.postgresql.Driver");
			objConn= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","postgres");
			
			objStmt = objConn.prepareStatement("INSERT INTO \"java project\".queries(\r\n"
					+ "	\"NAME\", \"EMAIL\", \"SUBJECT\", \"MESSAGE\")\r\n"
					+ "	VALUES (?, ?, ?, ?);");
			
			objStmt.setString(1,request.getParameter("Name"));
			objStmt.setString(2,request.getParameter("Email"));
			objStmt.setString(3,request.getParameter("Subject"));
			objStmt.setString(4,request.getParameter("Message"));
			
			objStmt.executeUpdate();
			
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			RequestDispatcher objdis = request.getRequestDispatcher("contact.html");
			objdis.include(request, response);
			out.println("<script type = \"text/javascript\">");
			out.println("alert('Queries has been sent successfully')"); 
			out.println("</script>");
	
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
